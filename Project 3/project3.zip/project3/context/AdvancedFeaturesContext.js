import { createContext } from 'react';

const AdvancedFeaturesContext = createContext();

export default AdvancedFeaturesContext;


